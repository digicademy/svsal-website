<xsl:stylesheet
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:xs="http://www.w3.org/2001/XMLSchema"
    xmlns:tei="http://www.tei-c.org/ns/1.0"
    version="2.0"
    exclude-result-prefixes="xs xsl"
    xpath-default-namespace="http://www.tei-c.org/ns/1.0">

<xsl:output omit-xml-declaration="no" indent="no"/>

<xsl:param name="format"        as="xs:string"/>
<xsl:param name="starting_facs" as="xs:string"/>
<xsl:param name="starting_newN" as="xs:string"/>

<xsl:template match="node() | @*" priority="2">
    <xsl:copy>
        <xsl:apply-templates select="node() | @*"/>
    </xsl:copy>
</xsl:template>

<xsl:template match="pb/@n[parent::pb/@facs ge $starting_facs]" priority="80">
    <xsl:variable name="deltaN">
        <xsl:value-of select="format-number(number(count(preceding::pb) - count(//pb[@facs=$starting_facs]/preceding::pb)), '0')"/>
    </xsl:variable>
    <xsl:attribute name="n">
        <xsl:choose>
            <xsl:when test="$format eq 'simple'">
                <xsl:value-of select="format-number(number($starting_newN) + number($deltaN), '0')"/>
            </xsl:when>
            <xsl:when test="$format eq 'folio'">
                <xsl:choose>
                    <xsl:when test="$deltaN mod 2 = 1">
                        <xsl:value-of select="concat('fol. ', format-number(ceiling((($deltaN *0.5) + (number($starting_newN) -1))), '0'), 'r')"/>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="concat('fol. ', format-number(ceiling((($deltaN *0.5) + (number($starting_newN) -1))), '0'), 'v')"/>
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>                                                            
            <xsl:when test="$format eq 'bracketed simple'">
                <xsl:value-of select="concat('[', format-number(number($starting_newN) + number($deltaN), '0'), ']')"/>
            </xsl:when>                                                            
            <xsl:when test="$format eq 'bracketed folio'">
                <xsl:choose>
                    <xsl:when test="$deltaN mod 2 = 1">
                        <xsl:value-of select="concat('[fol. ', format-number(ceiling((($deltaN *0.5) + (number($starting_newN) -1))), '0'), 'r]')"/>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="concat('[fol. ', format-number(ceiling((($deltaN *0.5) + (number($starting_newN) -1))), '0'), 'v]')"/>
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>                                                            
            <xsl:otherwise/>
        </xsl:choose>
    </xsl:attribute>
</xsl:template>
</xsl:stylesheet>
