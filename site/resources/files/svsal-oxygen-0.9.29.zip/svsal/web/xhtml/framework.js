goog.provide('sync.xhtml.XhtmlExtension');


/**
 * Constructor for the xhtml Extension.
 *
 * @constructor
 */
sync.xhtml.XhtmlExtension = function(){
  sync.ext.Extension.call(this);
};
goog.inherits(sync.xhtml.XhtmlExtension, sync.ext.Extension);

/**
 * Editor created callback.
 *
 * @param {sync.Editor} editor The currently created editor.
 */
sync.xhtml.XhtmlExtension.prototype.editorCreated = function(editor) {
  goog.events.listen(editor, sync.api.Editor.EventTypes.ACTIONS_LOADED, function(e) {
    var actionsManager = editor.getActionsManager();
    var originalInsertImageAction = actionsManager.getActionById('insert.image');
    if (originalInsertImageAction) {
      var insertImageAction = new sync.actions.InsertImage(
        originalInsertImageAction, 
        "ro.sync.ecss.extensions.xhtml.InsertImgOperation", 
        editor);
      actionsManager.registerAction('insert.image', insertImageAction);
    }
    
    var originalInsertTableAction = actionsManager.getActionById('insert.table');
    if (originalInsertTableAction) {
      var insertTableAction = new sync.actions.InsertTable(
        originalInsertTableAction, 
        "ro.sync.ecss.extensions.commons.table.operations.xhtml.InsertTableOperation", 
        editor, 
        [sync.actions.InsertTable.TableTypes.HTML],
        [sync.actions.InsertTable.ColumnWidthTypes.PROPORTIONAL, 
         sync.actions.InsertTable.ColumnWidthTypes.DYNAMIC, 
         sync.actions.InsertTable.ColumnWidthTypes.FIXED], 'Caption');
      actionsManager.registerAction('insert.table', insertTableAction);
    }
  });
};

// Publish the extension.
sync.ext.Registry.extension = new sync.xhtml.XhtmlExtension();